package url_shortener

import scala.collection._
import scala.util.Random
import scala.actors.Actor
import scala.actors.Actor._
import java.lang.management.ManagementFactory;
import java.lang.management.OperatingSystemMXBean;

class StorageMonitorThread extends Runnable {
  val time = new java.util.Date;
  val fileName: String = "statistics_"+(System.currentTimeMillis/1000).toString

  def initStatics() {
    val out = new java.io.FileWriter(fileName)
    out.write("Time,CPU,Memory,Total transactions handled,Total records stored,JVM CPU, JVM Heap Memory\n");
    out.flush();
    out.close();
    printf("Statistics Log File Created: %s\n", fileName)
  }
  def statics() {

    val topProcess = Runtime.getRuntime().exec("top -b -n 1");
    val topSource = io.Source.fromInputStream(topProcess.getInputStream());
    val out = new java.io.FileWriter(fileName, true);
    //JVM statistics
    val bean = ManagementFactory.getThreadMXBean();
    val mxbean = ManagementFactory.getOperatingSystemMXBean();
    val mebean = ManagementFactory.getMemoryMXBean();

    if (bean.isCurrentThreadCpuTimeSupported()) {
      bean.setThreadCpuTimeEnabled(true);
    }

    val lastThreadTime = bean.getCurrentThreadCpuTime();
    val lastNanoTime = System.nanoTime();
    val threads = bean.getAllThreadIds();
    var time1: Long = 0;
    for (i <- 0 until threads.length) {
      time1 += bean.getThreadCpuTime(threads(i));
    }

    val threadTime = bean.getCurrentThreadCpuTime();
    val nanoTime = System.nanoTime();
    val memoryUsage = mebean.getHeapMemoryUsage();
    val cpuJVM: Float = ((threadTime - lastThreadTime) / (nanoTime - lastNanoTime));

    //linux statistics
    val lines = topSource.getLines;
    for (i <- 0 to 1) { lines.next }
    val cpuLoad = lines.next.split(",")(0).substring(7, 12).trim.toFloat;
    val memory = lines.next.split(",")(1).substring(1, 9).trim.toLong;
    val totalTransactionsHandled = SurlMain.transactionsHandledNumber;
    val totalRecordsStored = UrlStorage.count;

    out.write(time + "," + cpuLoad + "," + memory + "k," + totalTransactionsHandled + "," + totalRecordsStored + "," + cpuJVM + "," + mebean.getHeapMemoryUsage() + "\n");
    out.flush();
    out.close();
    topSource.close();

  }

  def run() {
    println("Dynanmic Array Administrator Ready.")
    var click: Int = 0
    var oldCount: Int = 0
    try {
      initStatics()
    } catch {
      case _: Throwable => Nil
    }

    while (true) {
      if (UrlStorage.urlArrayContent.length - UrlStorage.count < 100000 / 2) {
        UrlStorage.urlArrayContent ++= new Array[Entry](100000)
        printf("Extend Array to %d, Free Memory: %d\n",
          UrlStorage.urlArrayContent.length, Runtime.getRuntime().freeMemory())

        ActionManager.actorInitArrayForShortUrl((UrlStorage.urlArrayContent.length - 100000), UrlStorage.urlArrayContent.length)

      }

      Thread.sleep(500)
      click += 1
      if (click > 10) {
        click = 0
        printf("Ongoing Web Threads: %d, Total Entries: %d, Rate %d/s\n", SurlMain.onGoingWebThreadNumber, UrlStorage.count, (UrlStorage.count - oldCount) / 5)
        oldCount = UrlStorage.count
        try {
          statics()
        } catch {
          case _: Throwable => Nil
        }
      }
    }
  }
}

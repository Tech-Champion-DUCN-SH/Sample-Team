package url_shortener
import java.lang.instrument.Instrumentation
import scala.Serializable
import scala.util.Random
import java.io.ByteArrayOutputStream
import java.io.ObjectOutputStream
import scala.concurrent._

class Entry {
  var longUrl: String = new String()
  var shortUrl: String = new String()
  var isValid: Boolean = false
}

object UrlStorage {
  var urlArrayContent: Array[Entry] = new Array[Entry](100000)

  var count: Int = 0
  var lock = new Lock()

  def init() {
    ActionManager.actorInitArrayForShortUrl(0, urlArrayContent.length)
  }

  private def getFreeIndex(): Int = {
    lock.acquire()
    count += 1
    var toReturn = count
    lock.release()
    return toReturn
  }

  def addEntry(URL: String): Int = {
    var idx: Int = getFreeIndex()
    urlArrayContent((idx)).longUrl = URL
    urlArrayContent((idx)).isValid = true

    return (idx)
  }

  def getEntry(idx: Int): String = {

    if (idx >= urlArrayContent.length || idx < 0 || urlArrayContent(idx).isValid == false) {
      throw new Exception
    }
    return new String(urlArrayContent(idx).longUrl)
  }
}

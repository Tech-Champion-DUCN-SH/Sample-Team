package url_shortener

import scala.collection._
import scala.actors.Actor
import scala.actors.Actor._
import scala.concurrent.Lock
import java.net.Socket
import java.io.StringReader
import java.net.URLDecoder
import java.io.OutputStream
import java.io.InputStream

class WebThread(s: Socket) extends Runnable {
  def realRun() {
    s.setSoTimeout(10000)
    var in = s.getInputStream()
    var out = s.getOutputStream()
    while (s.isConnected() && !s.isClosed()) {
      var parseResult = readAllAndParseFirstLine(in)

      if (parseResult._1 == 'W') {
          var result: String = ActionManager.putEntry(new String(parseResult._2))
          respondPut(out, parseResult._2, result)
          SurlMain.transactionsHandledNumber += 1
      } else if (parseResult._1 == 'R') {
        var result: String = ActionManager.getEntry(new String(parseResult._2))
        respondGet(out, parseResult._2, result)
        SurlMain.transactionsHandledNumber += 1
      } else {
        s.close()
      }
    }
  }

  def run() {
    SurlMain.onGoingWebThreadNumber += 1
    try {
      realRun()
    } catch {
      case _: Throwable => {
        try {
          s.close()
        } catch {
          case _: Throwable => Nil
        }
      }
    }
    SurlMain.onGoingWebThreadNumber -= 1
  }

  def respondPut(out: OutputStream, query: String, result: String) {
    var payloadLen = 45 + query.length() + SurlMain.localAddr.length() + result.length()

    out.write(staticOutStr.http200Ok)
    out.write(("Content-Length: " + payloadLen).getBytes)
    out.write(staticOutStr.shortenHeaderEnd)
    out.write(result.getBytes())
    out.write(staticOutStr.longurlPart)
    out.write(query.getBytes())
    out.write(staticOutStr.payloadEnd)
    out.flush()
  }

  def respondGet(out: OutputStream, query: String, longUrl: String) {
    var outstr = new String()

    if (longUrl == "NoTfOuNd") {
      out.write(staticOutStr.notFound)
    } else {
      var payloadLen = 44 + query.length() + longUrl.length()
      out.write(staticOutStr.http200Ok)
      out.write(("Content-Length: " + payloadLen).getBytes())
      out.write(staticOutStr.expandHeaderEnd)
      out.write(query.getBytes())
      out.write(staticOutStr.longurlPart)
      out.write(longUrl.getBytes())
      out.write(staticOutStr.payloadEnd)
    }
    out.flush()
  }

  def readAllAndParseFirstLine(in: InputStream): (Char, String) = {
    val buffer = new Array[Byte](512)
    var tmpstr: String = new String()
    var len: Int = 0
    var headerDeliPos: Int = 0
    var errorResp = ('E', "")
    var firstFlag = true

    while (true) {
      try {
        len = in.read(buffer, 0, 512)
        if (len <= 0) {
          return errorResp
        }
      } catch {
        case _: Throwable => {
          return errorResp
        }
      }

      if (firstFlag && len >= 4 && buffer(len - 3) == '\n' && buffer(len - 2) == '\r' && buffer(len - 1) == '\n') {
        tmpstr = new String(buffer).substring(0, len)
        headerDeliPos = len - 4
      } else {
        firstFlag = false
        tmpstr += new String(buffer).substring(0, len)
        headerDeliPos = tmpstr.indexOf("\r\n\r\n", tmpstr.length() - 4)
        if (headerDeliPos < 0) {
          headerDeliPos = tmpstr.indexOf("\r\n\r\n")
        }
      }

      if (headerDeliPos >= 0) {
        //println(tmpstr)
        var arrayStr = tmpstr.getBytes()
        if (arrayStr(0) != 'G' || arrayStr(1) != 'E') {
          return errorResp
        }

        var putPos = tmpstr.indexOf("?longUrl=")
        var getPos = tmpstr.indexOf("?shortUrl=")

        if (putPos > 0) {
          putPos += 9
          var tn: Int = putPos
          var chr: Byte = arrayStr(tn)

          while (chr != ' ') {
            tn += 1
            chr = arrayStr(tn)
          }
          var query: String = tmpstr.substring(putPos, tn)
          return ('W', URLDecoder.decode(query, "UTF-8"))
        } else if (getPos > 0) {
          getPos += 10
          var tn: Int = getPos
          var chr: Byte = arrayStr(tn)

          while (chr != ' ') {
            tn += 1
            chr = arrayStr(tn)
          }
          var query: String = tmpstr.substring(getPos, tn)
          return ('R', URLDecoder.decode(query, "UTF-8"))
        }
        // else
        return errorResp
      }
    }
    return errorResp
  }

  object staticOutStr {
    var notFound = "HTTP/1.1 404 Not Found\r\nContent-Type: application/json\r\nConnection: Keep-Alive\r\nContent-Length: 49\r\n\r\n{\"error\":\"true\",\"code\":404,\"message\":\"Not found\"}".getBytes()
    var serviceUnavailable = "HTTP/1.1 503 Service Unavailable\r\nContent-Type: application/json\r\nConnection: Keep-Alive\r\nContent-Length: 59\r\n\r\n{\"error\":\"true\",\"code\":503,\"message\":\"Service Unavailable\"}".getBytes()
    var http200Ok = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nConnection: Keep-Alive\r\n".getBytes()
    var expandHeaderEnd = "\r\n\r\n{\"kind\":\"expand\",\"shortUrl\":\"".getBytes()
    var shortenHeaderEnd = ("\r\n\r\n{\"kind\":\"shorten\",\"shortUrl\":\"" + SurlMain.localAddr).getBytes()
    var longurlPart = "\",\"longUrl\":\"".getBytes()
    var payloadEnd = "\"}".getBytes()
  }

  /*  
  def respondPut_BAK(s: Socket, query: String, result: String) {
    var shortUrl = SurlMain.localAddr + result
    var payload = "{\"kind\":\"shorten\",\"shortUrl\":\"" +
      shortUrl +
      "\",\"longUrl\":\"" +
      query + "\"}"
    var outstr = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nConnection: Keep-Alive\r\n" +
      "Content-Length: " + payload.length() + "\r\n\r\n" +
      payload
      
    //println(outstr)
    var out = s.getOutputStream()
    out.write(outstr.getBytes())
    out.flush()
  }
    
  def respondGet_BAK(s: Socket, query: String, longUrl: String) {
    var outstr = new String()

    if (longUrl == "NoTfOuNd") {
      var payload = "{\"error\":\"true\",\"code\":404,\"message\":\"Not found\"}"
      outstr = "HTTP/1.1 404 Not Found\r\nContent-Type: application/json\r\nConnection: Keep-Alive\r\n" +
        "Content-Length: " + payload.length() + "\r\n\r\n" + payload
    } else {
      var payload = "{\"kind\":\"expand\",\"shortUrl\":\"" +
        query +
        "\",\"longUrl\":\"" +
        longUrl + "\"}"
      outstr = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nConnection: Keep-Alive\r\n" +
        "Content-Length: " + payload.length() + "\r\n\r\n" +
        payload
    }
    //println(outstr)
    var out = s.getOutputStream()
    out.write(outstr.getBytes())
    out.flush()
  }
*/

}
package url_shortener

import scala.collection._
import scala.util.control.Breaks._
import scala.actors.Actor
import scala.actors.Actor._
import java.net._
import scala.util.Random
import java.io.StringBufferInputStream

object SurlMain {
  var localDomain: String = InetAddress.getLocalHost().getHostAddress()
  var localAddr: String = "http://" + localDomain + "/"
  var localAddrPos: Int = localAddr.length()
  var onGoingWebThreadNumber: Int = 0
  var transactionsHandledNumber: Int = 0
  var putServiceOn = true

  def main(args: Array[String]) {
    var startTime = System.currentTimeMillis
    var port: Int = 9000
    var bindDone = false

    printf("StartTime %d Milli Seconds, Initializaing...\n", startTime)

    ActionManager.init()
    UrlStorage.init()

    new Thread(new StorageMonitorThread()).start()

    val server = new ServerSocket()
    server.setReuseAddress(true)
    while (!bindDone) {
      try {
        server.bind(new InetSocketAddress(port))
        bindDone = true
      } catch {
        case _: Throwable => {
          port += 1
          printf("Binding port %d failed, try %d now\n", port-1, port)
        }
      }
    }
    printf("Init Done, Local Address is: %s, Listening at port: %d\n", localAddr, port)

    while (true) {
      val s: Socket = server.accept()
      try {
        new Thread(new WebThread(s)).start()
      } catch {
        case _: Throwable => {
          println("Thread Died...")
          try {
            s.close()
          } catch {
            case _: Throwable => Nil
          }
        }
      }
    }
    server.close()

    var endTime = System.currentTimeMillis
    printf("Server done. Time used %d Milli Seconds\n", endTime - startTime)
  }
}


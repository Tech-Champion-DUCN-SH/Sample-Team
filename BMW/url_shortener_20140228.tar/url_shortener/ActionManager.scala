package url_shortener

import scala.actors.Actor
import scala.actors.Actor._
import scala.concurrent.Lock

object ActionManager {
  val cores: Int = Runtime.getRuntime().availableProcessors()
  val actorNum: Int = cores * 4

  var actors: List[StorageExtendActor] = List()
  var cnt: Int = -1

  def init() {
    printf("Start with %d actors.\n", actorNum)
    for (x <- 0 until actorNum) {
      actors = actors ++ List(new StorageExtendActor())
      actors(x).start()
    }
  }

  def findAvailableActor(): Int = {
    cnt += 1
    if (cnt >= actors.length) {
      cnt = 0
    }
    return cnt
  }

  def putEntry(longUrl: String): String = {
    return UrlStorage.urlArrayContent(UrlStorage.addEntry(longUrl)).shortUrl
  }

  def getEntry(shortUrl: String): String = {
    try {
      //var sub: String = shortUrl.substring(shortUrl.indexOf('/', SurlMain.localAddrPos-1))
      var sub: String = shortUrl.substring(SurlMain.localAddrPos)
      return UrlStorage.getEntry(Convertor.surlToIndex(sub))
    } catch {
      case _: Throwable => return "NoTfOuNd"
    }
  }

  def actorInitArrayForShortUrl(start: Int, end: Int) {
    var actorId = 0
    for (x <- start until end) {
      actorId = findAvailableActor()
      actors(actorId) ! initArrayForShortUrl(x)
    }
  }

  def stop() {
    for (x <- 0 until actorNum) {
      actors(x) ! stop()
    }
  }
}

object refTable {
  //var preContent: String = "tF13GOlCxPbIXc9qwUJiWZapSVdgfTvHn28orD4uQkzBeRjMy5Y7A6KL0hNmEs"
  var preContent: String = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz"
  var content: Array[Byte] = preContent.getBytes()
  var digitSys: Int = content.length
  def getDigit(bchr: Byte): Int = {
    var chr = bchr.toChar
    if (chr >= 'A' && chr <= 'Z') {
      return (chr - 65)
    } else if (chr >= '0' && chr <= '9') {
      return (chr - 22)
    } else if (chr >= 'a' && chr <= 'z') {
      return (chr - 61)
    }
    throw new Exception()
  }
  /*
  def getDigit(chr: Byte): Int = {
    var x = 0;
    for (x <- 0 until content.length) {
      if (content(x) == chr) {
        return x
      }
    }
    return x
  }
  * 
  */
}

object Convertor {
  def surlToIndex(surl: String): Int = {
    var surlArray = surl.getBytes()
    var surlLen = surl.length()
    var index: Int = 0
    var powArray: Array[Int] = Array(1, 62, 3844, 238328, 14776336, 916132832)
    for (x <- 1 to surl.length()) {
      index += refTable.getDigit(surlArray(surlLen - x)) * powArray(x - 1)
    }
    return (index)
  }

  def indexToSurl(idx: Int): String = {
    var calIdx: Int = idx
    var newStr: Array[Byte] = new Array[Byte](10)
    var dev: Int = calIdx
    var byteAppend: Byte = 0
    var n: Int = 0

    while (dev > 0) {
      byteAppend = refTable.content(dev % refTable.digitSys)
      newStr(n) = byteAppend
      n += 1
      dev = dev / refTable.digitSys
    }

    var newTmpStr: Array[Byte] = new Array[Byte](n)
    Array.copy(newStr, 0, newTmpStr, 0, n)

    return new String(newTmpStr.reverse.toArray[Byte])
  }
}
package url_shortener

import scala.collection._
import scala.actors.Actor
import scala.actors.Actor._
import scala.concurrent.Lock



case class put(from: Actor, x: String)
case class get(from: Actor, x: String)
case class initArrayForShortUrl(x: Int)
case class stop()
case class getError()
//case class post(arrayBuff: Array[String], arrayCnt: Array[Int], id: Int, x: String, lock: Lock)

class StorageExtendActor() extends Actor {

  def act() {
    while (true) {
      receive {
        case put(from, x) => {
          val surl = UrlStorage.urlArrayContent(UrlStorage.addEntry(x)).shortUrl
          from ! surl
        }
        case get(from, x) => {
          try {
            var sub: String = new String()
            sub = x.substring(x.indexOf('/', 10))

            var lurl = UrlStorage.getEntry(Convertor.surlToIndex(sub))
            from ! lurl
          } catch {
            case _: Throwable => from ! getError()
          }

        }
        case initArrayForShortUrl(x) => {
          val entry: Entry = new Entry()
          entry.shortUrl = Convertor.indexToSurl(x)
          entry.isValid = false
          UrlStorage.urlArrayContent(x) = entry
        }
        /*case post(arrayBuff, arrayCnt, id, x, lock) => {
          val surl = Convertor.indexToSurl(UrlStorage.addEntry(x))
          arrayBuff(id) = surl
          lock.acquire()
          arrayCnt(0) = arrayCnt(0) + 1
          lock.release()
        }*/
        case stop() => {
          exit()
        }
      }
    }
  }
}



